const express = require('express');
const app = express();
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const bodyParser = require('body-parser');
const cookieparser = require('cookieparser');

// Import ROUTES
const authRoute = require('./Routes/auth'); 


dotenv.config();

//CONNECT TO DB
mongoose.connect(process.env.DB_CONNECTION, ()=>{
    console.log('Database Connected');
  })

 // Middleware
 app.use(express.json()); 

// Route Middlewares
app.use(cors);
app.use('/api/user', authRoute);
app.use(bodyParser.json());
app.use(cookieparser);


app.listen(3000, () => 
    console.log('Up and running')
);